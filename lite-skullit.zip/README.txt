To use:

Drag & Drop a skin file onto SKULLIT-LITE.exe

Open output.txt and copy the command

Paste it into a command block.



-------

If you get an error.txt, send it to me on discord @ ban#4444